#include "event.h"

class PrivateEvent: public Event {
 public:
  PrivateEvent();
  ~PrivateEvent ();
};
