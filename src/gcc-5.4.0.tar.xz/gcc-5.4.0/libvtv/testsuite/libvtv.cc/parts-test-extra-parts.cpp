#include "parts-test-extra-parts.h"

ExtraParts::ExtraParts () {}

ExtraParts::~ExtraParts () {}

void
ExtraParts::ToolkitInitialized ()
{
}

void
ExtraParts::PreEarlyInitialization ()
{
}
